
export const firstUrl = "https://fournisseur.firstdeliverygroup.com";
//export const baseUrl = "http://localhost:2233";
export const baseUrl = "https://diggie.jvmhost.net/cmb";

//export const baseUrl = "https://lyft.jvmhost.net/cmb";
export const APPNAME = "ABYSOFT";

