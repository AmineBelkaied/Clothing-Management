//export const baseUrl = "http://localhost:2233";
export const baseUrl = "https://diggie.jvmhost.net/cmb";
//export const baseUrlfirst = "https://diggie.jvmhost.net/apifirst";
//export let deliveryAPi = "first"
//export const deliveryUrlExpress="https://pro.tunisia-express.tn/api/";
//export const deliveryUrlFirst="https://www.firstdeliverygroup.com/api/diggie23-XATG547WLSA/v1/post.php";
//export const deliveryUrlFirstEtat="https://www.firstdeliverygroup.com/api/diggie23-etat-XATG547WLSA/v1/post.php";
//export const deliveryUrl=deliveryUrlFirst;
//export const deliveryUrl="http://pro.tunisia-express.tn/api/houb/additem?format=json&api_key=bbd4165152e845cbfdf9067688c7b62f";
//export const clientApiCodeExpress="dfbe9b469df33a124e07e243d6803c2e";
//export const clientApiCodeFirst="GH54G54FGI7JHFGZPO1CBRDS";
