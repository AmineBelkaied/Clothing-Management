
export const firstUrl = "https://fournisseur.firstdeliverygroup.com";
//export const baseUrl = "http://localhost:2233";
//export const baseUrl = "https://diggie.jvmhost.net/cmb";

export const baseUrl = "https://lyft.jvmhost.net/lyft";
export const APPNAME = "ABYSOFT";

//export const APPNAME = "DIGGIE";
//export let deliveryAPi = "first"
//export const deliveryUrlExpress="https://pro.tunisia-express.tn/api/";
//export const deliveryUrl=deliveryUrlFirst;
//export const deliveryUrl="http://pro.tunisia-express.tn/api/houb/additem?format=json&api_key=bbd4165152e845cbfdf9067688c7b62f";
//export const clientApiCodeExpress="dfbe9b469df33a124e07e243d6803c2e";
